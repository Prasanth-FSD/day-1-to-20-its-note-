<h1 align="center">Batch 54 Notes</h1>
<h3 align="center">HTML,CSS, JS.</h3>

ReadME Generator: https://rahuldkjain.github.io/gh-profile-readme-generator/ <br>

Gradient Generator: https://cssgradient.io/ <br>

Resume, Image edit: https://www.canva.com/ <br>

Flexbox Practice: https://flexboxfroggy.com/ <br>

Grid Practice: https://cssgridgarden.com/ <br>

Icon Version CDN: https://cdnjs.com/libraries/font-awesome/4.7.0 <br>

Icon: https://fontawesome.com/v4/icon/ <br>
Bootstrap CDN Link: <br>
-link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous"-

Glassmorphism - https://ui.glass/generator/ , https://css.glass/

Box Shadow - https://www.cssmatic.com/box-shadow

UI Design: https://dribbble.com/ , https://in.pinterest.com/

Animation: https://animotion.dev/

JS Link: https://javascript.info/, https://developer.mozilla.org/en-US/docs/Web/JavaScript

Codepen: https://codepen.io/

Readme Cheet: https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet , https://readme.so/editor
